# Installation

Link to install python: https://www.python.org/downloads/

Please make sure to install following packages before executing the script.
You can use the commands below in the python terminal to install packages

pip install requests
pip install csv
pip install pandas
pip install openpyxl
